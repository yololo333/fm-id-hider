const enabledToggle = document.getElementById("enabledToggle");
const modeBlurBtn = document.getElementById("modeBlur");
const modeHideBtn = document.getElementById("modeHide");
const pickerBtn = document.getElementById("pickerBtn");
const customSelectorsEl = document.getElementById("customSelectors");
const saveBtn = document.getElementById("saveBtn");

function renderMode(mode) {
  modeBlurBtn.classList.toggle("active", mode === "blur");
  modeHideBtn.classList.toggle("active", mode === "hide");
}

function renderPicker(active) {
  pickerBtn.classList.toggle("on", active);
  pickerBtn.textContent = active
    ? "🎯 선택 중... (페이지에서 닉네임 클릭)"
    : "🎯 놓친 아이디 직접 선택하기";
}

chrome.storage.sync.get(
  {
    fkih_enabled: true,
    fkih_mode: "blur",
    fkih_custom_selectors: [],
    fkih_picker_active: false
  },
  (data) => {
    enabledToggle.checked = data.fkih_enabled;
    renderMode(data.fkih_mode);
    renderPicker(data.fkih_picker_active);
    customSelectorsEl.value = (data.fkih_custom_selectors || []).join("\n");
  }
);

enabledToggle.addEventListener("change", () => {
  chrome.storage.sync.set({ fkih_enabled: enabledToggle.checked });
});

modeBlurBtn.addEventListener("click", () => {
  chrome.storage.sync.set({ fkih_mode: "blur" });
  renderMode("blur");
});

modeHideBtn.addEventListener("click", () => {
  chrome.storage.sync.set({ fkih_mode: "hide" });
  renderMode("hide");
});

pickerBtn.addEventListener("click", () => {
  chrome.storage.sync.get({ fkih_picker_active: false }, (data) => {
    const next = !data.fkih_picker_active;
    chrome.storage.sync.set({ fkih_picker_active: next });
    renderPicker(next);
    if (next) window.close(); // 팝업 닫고 페이지에서 바로 클릭 가능하게
  });
});

saveBtn.addEventListener("click", () => {
  const lines = customSelectorsEl.value
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);
  chrome.storage.sync.set({ fkih_custom_selectors: lines }, () => {
    saveBtn.textContent = "저장됨!";
    setTimeout(() => (saveBtn.textContent = "저장"), 1000);
  });
});

// 다른 곳(예: 피커로 선택자 추가됨)에서 값이 바뀌면 텍스트영역 갱신
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "sync") return;
  if (changes.fkih_custom_selectors) {
    customSelectorsEl.value = (changes.fkih_custom_selectors.newValue || []).join("\n");
  }
  if (changes.fkih_picker_active) {
    renderPicker(changes.fkih_picker_active.newValue);
  }
});
