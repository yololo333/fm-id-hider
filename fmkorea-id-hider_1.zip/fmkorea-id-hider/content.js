// 펨코 아이디 가리기 - content script
(function () {
  "use strict";

  const STORAGE_KEYS = {
    enabled: "fkih_enabled",
    mode: "fkih_mode", // 'hide' | 'blur'
    customSelectors: "fkih_custom_selectors", // array of strings
    pickerActive: "fkih_picker_active"
  };

  // 에펨코리아(XpressEngine 기반) 게시판/게시글/댓글에서 닉네임이 나타나는
  // 것으로 알려진 위치들. 사이트 마크업이 바뀌면 팝업의 "커스텀 선택자"에
  // 직접 추가해서 보완할 수 있음.
  const DEFAULT_SELECTORS = [
    // 게시글 목록 (리스트) 작성자
    "td.author a",
    "td.author",
    ".bd_lst .author a",
    ".bd_lst_wrt .author",
    // 게시글 본문 상단 작성자 표시
    ".top_content .side.fr a.member_plate",
    ".side.fr .member_plate",
    "a.member_plate",
    ".member_plate",
    // 댓글 작성자
    ".comment_nick",
    ".fdb_lst_wrp .comment_nick",
    ".xe_content .comment_wrap .member_plate",
    "li.comment_element .meta a",
    ".comment_box .meta .member_plate",
    // 모바일(m.fmkorea.com) 버전
    ".author_nick",
    ".writer_nick",
    // 답글(대댓글) 작성자
    "a.findParent"
  ];

  let state = {
    enabled: true,
    mode: "blur",
    customSelectors: [],
    pickerActive: false
  };

  let hoverBox = null;

  function getAllSelectors() {
    return DEFAULT_SELECTORS.concat(state.customSelectors || []);
  }

  function applyToElement(el) {
    if (!el || el.dataset.fkihSkip === "1") return;
    el.classList.remove("fkih-hidden", "fkih-blur");
    if (!state.enabled) return;
    if (state.mode === "hide") {
      el.classList.add("fkih-hidden");
    } else {
      el.classList.add("fkih-blur");
    }
  }

  function removeAll() {
    document.querySelectorAll(".fkih-hidden, .fkih-blur").forEach((el) => {
      el.classList.remove("fkih-hidden", "fkih-blur");
    });
  }

  function runPass() {
    if (!state.enabled) {
      removeAll();
      return;
    }
    const selectors = getAllSelectors();
    selectors.forEach((sel) => {
      let nodes;
      try {
        nodes = document.querySelectorAll(sel);
      } catch (e) {
        return; // 잘못된 커스텀 선택자는 무시
      }
      nodes.forEach(applyToElement);
    });
  }

  // ---- 저장소 로드/저장 ----
  function loadState(cb) {
    chrome.storage.sync.get(
      {
        [STORAGE_KEYS.enabled]: true,
        [STORAGE_KEYS.mode]: "blur",
        [STORAGE_KEYS.customSelectors]: []
      },
      (data) => {
        state.enabled = data[STORAGE_KEYS.enabled];
        state.mode = data[STORAGE_KEYS.mode];
        state.customSelectors = data[STORAGE_KEYS.customSelectors];
        if (cb) cb();
      }
    );
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    let needsRun = false;
    if (STORAGE_KEYS.enabled in changes) {
      state.enabled = changes[STORAGE_KEYS.enabled].newValue;
      needsRun = true;
    }
    if (STORAGE_KEYS.mode in changes) {
      state.mode = changes[STORAGE_KEYS.mode].newValue;
      needsRun = true;
    }
    if (STORAGE_KEYS.customSelectors in changes) {
      state.customSelectors = changes[STORAGE_KEYS.customSelectors].newValue;
      needsRun = true;
    }
    if (needsRun) {
      removeAll();
      runPass();
    }
  });

  // ---- 요소 선택(피커) 모드: 팝업에서 켜면 마우스오버 하이라이트 후 클릭으로 선택자 추가 ----
  function ensureHoverBox() {
    if (hoverBox) return hoverBox;
    hoverBox = document.createElement("div");
    hoverBox.style.position = "fixed";
    hoverBox.style.pointerEvents = "none";
    hoverBox.style.border = "2px solid #ff3b30";
    hoverBox.style.background = "rgba(255,59,48,0.15)";
    hoverBox.style.zIndex = "2147483647";
    hoverBox.style.display = "none";
    document.documentElement.appendChild(hoverBox);
    return hoverBox;
  }

  function buildSelectorFor(el) {
    if (el.id) return "#" + CSS.escape(el.id);
    const cls = (el.className && typeof el.className === "string")
      ? el.className.trim().split(/\s+/).filter(Boolean)
      : [];
    if (cls.length > 0) {
      return el.tagName.toLowerCase() + "." + cls.map((c) => CSS.escape(c)).join(".");
    }
    // fallback: tag + nth-child within parent
    const parent = el.parentElement;
    if (!parent) return el.tagName.toLowerCase();
    const idx = Array.prototype.indexOf.call(parent.children, el) + 1;
    return el.tagName.toLowerCase() + `:nth-child(${idx})`;
  }

  function onPickerMouseMove(e) {
    if (!state.pickerActive) return;
    const box = ensureHoverBox();
    const r = e.target.getBoundingClientRect();
    box.style.display = "block";
    box.style.left = r.left + "px";
    box.style.top = r.top + "px";
    box.style.width = r.width + "px";
    box.style.height = r.height + "px";
  }

  function onPickerClick(e) {
    if (!state.pickerActive) return;
    e.preventDefault();
    e.stopPropagation();
    const sel = buildSelectorFor(e.target);
    chrome.storage.sync.get({ [STORAGE_KEYS.customSelectors]: [] }, (data) => {
      const list = data[STORAGE_KEYS.customSelectors];
      if (!list.includes(sel)) {
        list.push(sel);
        chrome.storage.sync.set({ [STORAGE_KEYS.customSelectors]: list });
      }
      chrome.storage.sync.set({ [STORAGE_KEYS.pickerActive]: false });
    });
    if (hoverBox) hoverBox.style.display = "none";
  }

  chrome.storage.sync.get({ [STORAGE_KEYS.pickerActive]: false }, (data) => {
    state.pickerActive = data[STORAGE_KEYS.pickerActive];
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "sync" && STORAGE_KEYS.pickerActive in changes) {
      state.pickerActive = changes[STORAGE_KEYS.pickerActive].newValue;
      if (!state.pickerActive && hoverBox) hoverBox.style.display = "none";
    }
  });

  document.addEventListener("mousemove", onPickerMouseMove, true);
  document.addEventListener("click", onPickerClick, true);

  // ---- 동적 로딩(무한스크롤/AJAX 댓글) 대응 ----
  let debounceTimer = null;
  const observer = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(runPass, 120);
  });

  function start() {
    observer.observe(document.documentElement, { childList: true, subtree: true });
    runPass();
  }

  loadState(() => {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", start);
    } else {
      start();
    }
  });
})();
